<!-- JS
============================================ -->
<!--jquery min js-->
<script src="<?= $site ?>assets/js/vendor/jquery-3.4.1.min.js"></script>
<!--popper min js-->
<script src="<?= $site ?>assets/js/popper.js"></script>
<!--bootstrap min js-->
<script src="<?= $site ?>assets/js/bootstrap.min.js"></script>
<!--owl carousel min js-->
<script src="<?= $site ?>assets/js/owl.carousel.min.js"></script>
<!--slick min js-->
<script src="<?= $site ?>assets/js/slick.min.js"></script>
<!--magnific popup min js-->
<script src="<?= $site ?>assets/js/jquery.magnific-popup.min.js"></script>
<!--jquery countdown min js-->
<script src="<?= $site ?>assets/js/jquery.countdown.js"></script>
<!--jquery ui min js-->
<script src="<?= $site ?>assets/js/jquery.ui.js"></script>
<!--jquery elevatezoom min js-->
<script src="<?= $site ?>assets/js/jquery.elevatezoom.js"></script>
<!--isotope packaged min js-->
<script src="<?= $site ?>assets/js/isotope.pkgd.min.js"></script>
<!-- Plugins JS -->
<script src="<?= $site ?>assets/js/plugins.js"></script>

<!-- Main JS -->
<script src="<?= $site ?>assets/js/main.js"></script>